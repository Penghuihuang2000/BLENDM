estimate_dispersion <- function(obs.data, mean,
                                lower = 1e-6,
                                upper = 1e3) {
  x <- obs.data
  stopifnot(length(x) == length(mean),
            all(x > 0 & x < 1),
            all(mean > 0 & mean < 1))
  G <- length(x)
  
  # score function for dispersion
  score <- function(dispersion) {
    G * digamma(dispersion) -
      sum(mean * digamma(mean * dispersion) +
            (1 - mean) * digamma((1 - mean) * dispersion)) +
      sum(mean * log(x) + (1 - mean) * log(1 - x))
  }
  # check that the root is bracketed
  s_low <- score(lower)
  s_up  <- score(upper)
  while(s_low * s_up > 0){
    upper <- 2*upper
    s_up  <- score(upper)
  }
  res <- uniroot(score, lower = lower, upper = upper)
  return(res$root)
}


twostep_decon <- function(mixture_sample, reference.list){
  M <- unlist(lapply(reference.list, ncol))
  G <- nrow(mixture_sample)
  ct <- names(reference.list)
  N <- ncol(mixture_sample)
  library(nnls)
  reference.mtx <- as.matrix(rlist::list.cbind(reference.list))
  mixture_sample[which(mixture_sample==1)] <- (1 - 1e-15)
  mixture_sample[which(mixture_sample==0)] <- 1e-15
  
  one_run <- function(reference.mtx, mixture_sample){
    nnls_res <- lapply(1:ncol(mixture_sample), function(i){
      tmp_res <- nnls(reference.mtx,mixture_sample[,i])
      tmp_res
    })
    frac_est <- rlist::list.rbind(lapply(nnls_res, function(res){res$x}))
    frac_est <- t(apply(frac_est, 1, function(x){x/sum(x)}))
    return(list("frac" = frac_est))
  }
  initialize <- one_run(reference.mtx, mixture_sample)
  fitted_mean <- reference.mtx %*% t(initialize$frac) 
  rm(initialize)
  dispersion_est <- sapply(1:G, function(i){estimate_dispersion(mixture_sample[i,],
                                                                fitted_mean[i,])})
  
  ## function: given a vector of mean, a vector of dispersion, calculate sds
  beta_sd <- function(mean_vec, dispersion_vec){
    return(sqrt((mean_vec*(1-mean_vec))/dispersion_vec))
  }
  sd_est <- sapply(1:N, function(i){beta_sd(fitted_mean[,i], dispersion_est)})
  inverse_cpg_sd <- 1/sd_est
  rm(sd_est)
  
  
  one_sample_wnnls <- function(single_sample, reference.mtx, inverse_sd){
    nnls_res <- nnls(apply(reference.mtx, 2, function(x){x*inverse_sd}),
                     single_sample*inverse_sd)
    return(nnls_res$x)
  }
  # refit using weighted nnls
  refit <- t(sapply(1:N, function(i){one_sample_wnnls(mixture_sample[,i],
                                                      reference.mtx,
                                                      inverse_cpg_sd[,i])}))
  
  group_labels <- rep(names(M), times = M)
  frac_est_new <- t(apply(refit, 1, function(x)tapply(x, group_labels, sum)))
  all_res <- t(apply(frac_est_new, 1, function(x){x/sum(x)}))
  return(all_res)
}
















