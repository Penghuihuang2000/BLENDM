res_fitting <- readRDS("Holland_cord_450k_GSE97628/res_beta_fitting.RDS")
library(SummarizedExperiment)
library(minfi)
load("adultcord.comb.processed.RData")
Meta_data <- as.data.frame(colData(rgSet))
Meta_data[which(Meta_data$Sample_Group=="ChristensenLab"),"Study"] <- "Salas"
for(i in 1:nrow(Meta_data)){
  if(is.na(Meta_data[i,"Study"])){Meta_data[i,"Study"] <- "Reinius"}
}
Meta_data$cord_adult <- sapply(Meta_data$Study,
                               function(study){
                                 ifelse(study %in% c("Reinius","Salas"), "adult", "cord")})
betaRaw <- getBeta(rgSet)
betaRaw <- betaRaw[,rownames(Meta_data)] 
drop.na <- apply(betaRaw, 1, function(x){any(is.na(x))})
betaRaw <- betaRaw[!drop.na,]

inter_site <- intersect(rownames(res_fitting), rownames(betaRaw))
betaRaw <- betaRaw[inter_site,]
res_fitting <- res_fitting[inter_site,]
dim(betaRaw) # 349808    342
dim(Meta_data) # 342  39
dim(res_fitting) # 349808      2
rm(rgSet)
gc()

library(MASS)
fit_gamma <- fitdistr(res_fitting[,2], densfun = "gamma", lower = c(0,0))
fit_gamma
shape <- fit_gamma$estimate["shape"] 
rate  <- fit_gamma$estimate["rate"] 
save(betaRaw, Meta_data, shape, rate,
     file = "sim_raw_dat.RData")


