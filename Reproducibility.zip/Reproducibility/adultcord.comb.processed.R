# 1.0a Adult datasets
# salas data
#BiocManager::install("ExperimentHub",force=TRUE)
library(ExperimentHub)
hub <- ExperimentHub()
query(hub, "FlowSorted.Blood.EPIC")
FlowSorted.Blood.EPIC <- hub[["EH1136"]]
#BiocManager::install("IlluminaHumanMethylationEPICmanifest")
library(minfi)
MSet_Salas <- preprocessRaw(FlowSorted.Blood.EPIC)
dim(MSet_Salas) # [1] 866091     49

# Reinius data
library(FlowSorted.Blood.450k)
Rein <- FlowSorted.Blood.450k
MSet_Rein <- preprocessRaw(Rein)
dim(MSet_Rein) # [1] 485512     60

# combine the adult datasets
adult.comb <- combineArrays(FlowSorted.Blood.EPIC, Rein,
                            outType = "IlluminaHumanMethylation450k")
# 1.0b Cordblood datasets
hub <- ExperimentHub()
query(hub, "FlowSorted.CordBloodCombined.450k")
FlowSorted.CordBloodCombined.450k <- hub[["EH2256"]]
MSet_CordCombined <- preprocessRaw(FlowSorted.CordBloodCombined.450k)
dim(MSet_CordCombined) # [1] 453093    289

# 1.0c Combine cord blood and adult
# combine the cord and adult datasets
adultcord.comb <- combineArrays(adult.comb, FlowSorted.CordBloodCombined.450k,
                                outType = "IlluminaHumanMethylation450k")
dim(adultcord.comb) # [1] 575130    398
md <- colData(adultcord.comb)
rgSet <- adultcord.comb

library(minfi)
library(IlluminaHumanMethylation450kanno.ilmn12.hg19)
library(maxprobes)   # for dropXreactiveLoci()

rgSet <- adultcord.comb
## regular steps
## 1) Remove sex‐chromosome probes
annot    <- getAnnotation(rgSet)
keep.sex <- !(annot$chr %in% c("chrX","chrY"))
rgSet    <- rgSet[keep.sex, ]
## 2) Compute detection p-values on the RGChannelSet
detP     <- detectionP(rgSet)             # matrix: probes × samples
keep.det <- rowSums(detP > 0.01) == 0     # TRUE if p ≤ 0.01 in every sample
rgSet    <- rgSet[keep.det, ]
## 3) (now that it’s still an RGChannelSet) map and drop SNP’d probes
rgSet <- mapToGenome(rgSet)
rgSet <- dropLociWithSnps(rgSet, snps = c("CpG","SBE"))
## 4) Remove cross‐reactive loci
rgSet <- dropXreactiveLoci(rgSet)
save(rgSet, file = "adultcord.comb.processed.RData")

