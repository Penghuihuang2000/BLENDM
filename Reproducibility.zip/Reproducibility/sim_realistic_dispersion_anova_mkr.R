load("sim_raw_dat.RData")
load("sim_design.RData")
markers <- read.table("markers.txt")[,1]
source("BLEND_twostep.R")
library(EpiDISH)
set.seed(143)
keep_cpg <- intersect(rownames(betaRaw),markers) 
betaRaw <- betaRaw[keep_cpg,]
gc()
dispersion_gamma_shape <- shape
dispersion_gamma_rate <- rate
N <- 30
groups <- 10

cord_mean_fraction <- 0.01*c(
  Bcell = 8,
  CD4T  = 20,
  CD8T  = 10,
  Gran  = 42,
  Mono  =  5,
  NK    = 10,
  nRBC  =  5
)
cord_sd_fraction <- 0.02
cord_mix_fraction <- sapply(1:7,
                            function(i){rnorm(N*groups, cord_mean_fraction[i], cord_sd_fraction)})
for(i in 1:nrow(cord_mix_fraction)){
  for(j in 1:ncol(cord_mix_fraction)){
    if(cord_mix_fraction[i,j]<0){cord_mix_fraction[i,j] <- 0}
  }
}
cord_mix_fraction <- t(apply(cord_mix_fraction, 1, function(x){x/sum(x)}))
colnames(cord_mix_fraction) <- names(cord_mean_fraction)
f <- rep(1:groups, each = N)
tmp <- cord_mix_fraction
indices <- split(seq_len(nrow(tmp)), f)        
cord_mix_fraction <- lapply(indices, function(id) tmp[id, , drop = FALSE])


adult_mean_fraction <- c(
  Bcell = 0.05,   
  CD4T  = 0.20,   
  CD8T  = 0.10,   
  Mono  = 0.05,   
  Neu   = 0.55,   
  NK    = 0.05   
)
adult_sd_fraction <- 0.02
adult_mix_fraction <- sapply(1:6,
                             function(i){rnorm(N*groups, adult_mean_fraction[i], adult_sd_fraction)})
for(i in 1:nrow(adult_mix_fraction)){
  for(j in 1:ncol(adult_mix_fraction)){
    if(adult_mix_fraction[i,j]<0){adult_mix_fraction[i,j] <- 0}
  }
}
adult_mix_fraction <- t(apply(adult_mix_fraction, 1, function(x){x/sum(x)}))
colnames(adult_mix_fraction) <- names(adult_mean_fraction)
tmp <- adult_mix_fraction
indices <- split(seq_len(nrow(tmp)), f)        
adult_mix_fraction <- lapply(indices, function(id) tmp[id, , drop = FALSE])

sim_mixture <- function(pure_beta, mix_frac,
                        dispersion_gamma_shape, dispersion_gamma_rate){
  mix_sample <- pure_beta %*% t(mix_frac)
  dispersion_par <- rgamma(nrow(mix_sample), 
                           shape = dispersion_gamma_shape,
                           rate = dispersion_gamma_rate)
  for(j in 1:ncol(mix_sample)){
    mix_sample[,j] <- sapply(1:length(mix_sample[,j]), function(i){
      rbeta(1,shape1 = mix_sample[i,j]*dispersion_par[i],
            shape2 = (1-mix_sample[i,j])*dispersion_par[i])
    })
  }
  return(mix_sample)
}

ref_prep <- function(betaRaw, Meta_data){
  keep.ct <- unique(Meta_data$CellType)
  reference.list <- list()
  for(i in 1:length(keep.ct)){
    reference.list <- c(reference.list, list(betaRaw[,Meta_data$CellType == keep.ct[i]]))
  }
  names(reference.list) <- keep.ct
  return(reference.list)
}


ref_prep_epidish <- function(betaRaw, Meta_data){
  Meta_data$combo <- paste0(Meta_data$cord_adult,"_", Meta_data$CellType)
  keep.ct <- unique(Meta_data$combo)
  reference.list <- list()
  for(i in 1:length(keep.ct)){
    reference.list <- c(reference.list, list(betaRaw[,Meta_data$combo == keep.ct[i]]))
  }
  names(reference.list) <- keep.ct
  epidish.ref <- rlist::list.cbind(lapply(reference.list, rowMeans))
  return(epidish.ref)
}


test_cord_twostep <- function(sample.id, dispersion_gamma_shape, dispersion_gamma_rate){
  mixture_sample <- sim_mixture(betaRaw[,cord_mix_idx[sample.id,]],
                                cord_mix_fraction[[sample.id]],
                                dispersion_gamma_shape, dispersion_gamma_rate)
  reference.list <- ref_prep(betaRaw[,-cord_mix_idx[sample.id,]],
                             Meta_data[-cord_mix_idx[sample.id,],])
  reference.list <- reference.list[colnames(cord_mix_fraction[[1]])]
  
  tmp_res <- twostep_decon(mixture_sample, reference.list)
  return(tmp_res)
}

test_adult_twostep <- function(sample.id, dispersion_gamma_shape, dispersion_gamma_rate){
  mixture_sample <- sim_mixture(betaRaw[,adult_mix_idx[sample.id,]],
                                adult_mix_fraction[[sample.id]],
                                dispersion_gamma_shape, dispersion_gamma_rate)
  reference.list <- ref_prep(betaRaw[,-adult_mix_idx[sample.id,]],
                             Meta_data[-adult_mix_idx[sample.id,],])
  reference.list <- reference.list[colnames(adult_mix_fraction[[1]])]
  tmp_res <- twostep_decon(mixture_sample, reference.list)
  return(tmp_res)
}



test_cord_epidish <- function(sample.id, dispersion_gamma_shape, dispersion_gamma_rate){
  mixture_sample <- sim_mixture(betaRaw[,cord_mix_idx[sample.id,]],
                                cord_mix_fraction[[sample.id]],
                                dispersion_gamma_shape, dispersion_gamma_rate)
  epidish.ref <- ref_prep_epidish(betaRaw[,-cord_mix_idx[sample.id,]],
                                  Meta_data[-cord_mix_idx[sample.id,],])
  epidish.ref <- epidish.ref[,-which(colnames(epidish.ref)=="adult_Neu")]
  tmp_res <- epidish(mixture_sample,epidish.ref)
  tmp_res <- tmp_res$estF
  ct_combo <- colnames(tmp_res)
  ct <- unlist(lapply(strsplit(ct_combo,"_"), function(x){x[[2]]}))
  tmp_res <- t(apply(tmp_res, 1, function(x){tapply(x, ct, sum)}))
  return(tmp_res)
}


test_adult_epidish <- function(sample.id, dispersion_gamma_shape, dispersion_gamma_rate){
  mixture_sample <- sim_mixture(betaRaw[,adult_mix_idx[sample.id,]],
                                adult_mix_fraction[[sample.id]],
                                dispersion_gamma_shape, dispersion_gamma_rate)
  epidish.ref <- ref_prep_epidish(betaRaw[,-adult_mix_idx[sample.id,]],
                                  Meta_data[-adult_mix_idx[sample.id,],])
  epidish.ref <- epidish.ref[,-which(colnames(epidish.ref) %in% c("adult_Gran", "cord_Gran", "cord_nRBC"))]
  tmp_res <- epidish(mixture_sample,epidish.ref)
  tmp_res <- tmp_res$estF
  ct_combo <- colnames(tmp_res)
  ct <- unlist(lapply(strsplit(ct_combo,"_"), function(x){x[[2]]}))
  tmp_res <- t(apply(tmp_res, 1, function(x){tapply(x, ct, sum)}))
  return(tmp_res)
}

library(EMeth)
test_cord_EMeth <- function(sample.id, dispersion_gamma_shape, dispersion_gamma_rate){
  library(EMeth)
  mixture_sample <- sim_mixture(betaRaw[,cord_mix_idx[sample.id,]],
                                cord_mix_fraction[[sample.id]],
                                dispersion_gamma_shape, dispersion_gamma_rate)
  epidish.ref <- ref_prep_epidish(betaRaw[,-cord_mix_idx[sample.id,]],
                                  Meta_data[-cord_mix_idx[sample.id,],])
  epidish.ref <- epidish.ref[,-which(colnames(epidish.ref)=="adult_Neu")]
  tmp_res <- cv.emeth(Y = mixture_sample, eta = rep(1e-4, ncol(mixture_sample)), mu = epidish.ref, aber = TRUE, nu = nrow(mixture_sample)*(10^seq(-2,1,1)))
  tmp_res <- tmp_res$result$rho
  colnames(tmp_res) <- colnames(epidish.ref)
  ct_combo <- colnames(tmp_res)
  ct <- unlist(lapply(strsplit(ct_combo,"_"), function(x){x[[2]]}))
  tmp_res <- t(apply(tmp_res, 1, function(x){tapply(x, ct, sum)}))
  return(tmp_res)
}

library(EMeth)
test_adult_EMeth <- function(sample.id, dispersion_gamma_shape, dispersion_gamma_rate){
  library(EMeth)
  mixture_sample <- sim_mixture(betaRaw[,adult_mix_idx[sample.id,]],
                                adult_mix_fraction[[sample.id]],
                                dispersion_gamma_shape, dispersion_gamma_rate)
  epidish.ref <- ref_prep_epidish(betaRaw[,-adult_mix_idx[sample.id,]],
                                  Meta_data[-adult_mix_idx[sample.id,],])
  epidish.ref <- epidish.ref[,-which(colnames(epidish.ref) %in% c("adult_Gran", "cord_Gran", "cord_nRBC"))]
  tmp_res <- cv.emeth(Y = mixture_sample, eta = rep(1e-4, ncol(mixture_sample)), mu = epidish.ref, aber = TRUE, nu = nrow(mixture_sample)*(10^seq(-2,1,1)))
  tmp_res <- tmp_res$result$rho
  colnames(tmp_res) <- colnames(epidish.ref)
  ct_combo <- colnames(tmp_res)
  ct <- unlist(lapply(strsplit(ct_combo,"_"), function(x){x[[2]]}))
  tmp_res <- t(apply(tmp_res, 1, function(x){tapply(x, ct, sum)}))
  return(tmp_res)
}


run_OLS <- function(mixture, ref){
  tmp_df <- cbind(mixture, ref)
  tmp_df <- as.data.frame(tmp_df)
  colnames(tmp_df) <- c("bulk",colnames(ref))
  tmp_lm <- lm(bulk~ . -1, data = tmp_df)
  return(coef(tmp_lm))
}
OLS_deconv <- function(bulk, ref){
  tmp <- apply(bulk, 2, function(x){run_OLS(x, ref)})
  tmp <- apply(tmp, c(1,2), function(x){ifelse(x<0,0,x)})
  return(t(tmp))
}

test_cord_OLS <- function(sample.id, dispersion_gamma_shape, dispersion_gamma_rate){
  mixture_sample <- sim_mixture(betaRaw[,cord_mix_idx[sample.id,]],
                                cord_mix_fraction[[sample.id]],
                                dispersion_gamma_shape, dispersion_gamma_rate)
  epidish.ref <- ref_prep_epidish(betaRaw[,-cord_mix_idx[sample.id,]],
                                  Meta_data[-cord_mix_idx[sample.id,],])
  epidish.ref <- epidish.ref[,-which(colnames(epidish.ref)=="adult_Neu")]
  tmp_res <- OLS_deconv(mixture_sample,epidish.ref)
  ct_combo <- colnames(tmp_res)
  ct <- unlist(lapply(strsplit(ct_combo,"_"), function(x){x[[2]]}))
  tmp_res <- t(apply(tmp_res, 1, function(x){tapply(x, ct, sum)}))
  tmp_res <- t(apply(tmp_res, 1, function(x){x/sum(x)}))
  return(tmp_res)
}


test_adult_OLS <- function(sample.id, dispersion_gamma_shape, dispersion_gamma_rate){
  mixture_sample <- sim_mixture(betaRaw[,adult_mix_idx[sample.id,]],
                                adult_mix_fraction[[sample.id]],
                                dispersion_gamma_shape, dispersion_gamma_rate)
  epidish.ref <- ref_prep_epidish(betaRaw[,-adult_mix_idx[sample.id,]],
                                  Meta_data[-adult_mix_idx[sample.id,],])
  epidish.ref <- epidish.ref[,-which(colnames(epidish.ref) %in% c("adult_Gran", "cord_Gran", "cord_nRBC"))]
  tmp_res <- OLS_deconv(mixture_sample,epidish.ref)
  ct_combo <- colnames(tmp_res)
  ct <- unlist(lapply(strsplit(ct_combo,"_"), function(x){x[[2]]}))
  tmp_res <- t(apply(tmp_res, 1, function(x){tapply(x, ct, sum)}))
  tmp_res <- t(apply(tmp_res, 1, function(x){x/sum(x)}))
  return(tmp_res)
}

library(foreach)
library(doParallel)

cl <- makeCluster(groups)
registerDoParallel(cl)
cord_res_tmp <- foreach(id = 1:groups) %dopar% {
  test_cord_twostep(id, dispersion_gamma_shape, dispersion_gamma_rate)
}
stopCluster(cl)
cord_res_twostep <- rlist::list.rbind(cord_res_tmp)
gc()


cl <- makeCluster(groups)
registerDoParallel(cl)
adult_res_tmp <- foreach(id = 1:groups) %dopar% {
  test_adult_twostep(id, dispersion_gamma_shape, dispersion_gamma_rate)
}
stopCluster(cl)
adult_res_twostep <- rlist::list.rbind(adult_res_tmp)
gc()


cl <- makeCluster(groups)
registerDoParallel(cl)
cord_res_tmp <- foreach(id = 1:groups,
                        .packages = "EpiDISH") %dopar% {
                          test_cord_epidish(id, dispersion_gamma_shape, dispersion_gamma_rate)
                        }
stopCluster(cl)
cord_res_tmp <- rlist::list.rbind(cord_res_tmp)
cord_res_epidish <- cord_res_tmp
gc()



cl <- makeCluster(groups)
registerDoParallel(cl)
adult_res_tmp <- foreach(id = 1:groups,
                         .packages = "EpiDISH") %dopar% {
                           test_adult_epidish(id, dispersion_gamma_shape, dispersion_gamma_rate)
                         }
stopCluster(cl)
adult_res_tmp <- rlist::list.rbind(adult_res_tmp)
adult_res_epidish <- adult_res_tmp
gc()

cl <- makeCluster(groups)
registerDoParallel(cl)
cord_res_tmp <- foreach(id = 1:groups) %dopar% {
  test_cord_OLS(id, dispersion_gamma_shape, dispersion_gamma_rate)
}
stopCluster(cl)
cord_res_tmp <- rlist::list.rbind(cord_res_tmp)
cord_res_OLS <- cord_res_tmp
gc()

cl <- makeCluster(groups)
registerDoParallel(cl)
adult_res_tmp <- foreach(id = 1:groups) %dopar% {
  test_adult_OLS(id, dispersion_gamma_shape, dispersion_gamma_rate)
}
stopCluster(cl)
adult_res_tmp <- rlist::list.rbind(adult_res_tmp)
adult_res_OLS <- adult_res_tmp
gc()


cl <- makeCluster(groups)
registerDoParallel(cl)
cord_res_tmp <- foreach(id = 1:groups,
                        .packages = "EMeth") %dopar% {
                          test_cord_EMeth(id, dispersion_gamma_shape, dispersion_gamma_rate)
                        }
stopCluster(cl)
cord_res_tmp <- rlist::list.rbind(cord_res_tmp)
cord_res_EMeth <- cord_res_tmp
gc()

cl <- makeCluster(groups)
registerDoParallel(cl)
adult_res_tmp <- foreach(id = 1:groups,
                         .packages = "EMeth") %dopar% {
                           test_adult_EMeth(id, dispersion_gamma_shape, dispersion_gamma_rate)
                         }
stopCluster(cl)
adult_res_tmp <- rlist::list.rbind(adult_res_tmp)
adult_res_EMeth <- adult_res_tmp
gc()

cord_mix_fraction <- rlist::list.rbind(cord_mix_fraction)
adult_mix_fraction <- rlist::list.rbind(adult_mix_fraction)


